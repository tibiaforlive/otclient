# Kingdom Bot
Iniciado em 2017, este projeto visa a criação de um bot amplo
como os que já existem para o client de tibia comum(criado pela cipsoft),
bots como elfbot, redbot, tibiaAuto, ibot, e candybot(bot para otclient), e etc. Servem de
inspiração para este projeto.

Ainda esta em fase de construção, mas já tenho alguns planos de funções a serem
implementadas nesse bot, coisas como:

- Auto Heal com friend list
- Targeting
- Looting
- Cavebot

Essas sao as coisas principais pra a serem implementadas, mas não sao as
unica. Quero colocar muito mais coisas e realmente fazer um bot completo.

# Contribua
Voce tambem pode contribuir para o projeto da maneira que for possivel,
basta saber programar e criar variáveis com nomes legíveis. 
